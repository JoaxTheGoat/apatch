# Auditoria do M002_v1 — veredito item a item

Uma auditoria externa (outra IA) apontou 4 "bugs" e 3 lacunas. Cada alegação foi conferida **no código**.
Nada aqui foi compilado ou executado; os testes novos rodam no CI (`gradle testDebugUnitTest`).

| # | Alegação | Veredito | O que realmente é | Ação (v2) |
|---|----------|----------|-------------------|-----------|
| 1 | `scheduleExpiry` vaza coroutines | **Parcialmente correto** | Cada upsert criava um timer novo sem cancelar o anterior. Mas o `Expire` já carrega `expectedExpiry` e é ignorado se obsoleto, então **não há erro de lógica**, só desperdício. | Um timer por `activityId` (`expiryJobs`), cancelado em Dismiss/Clear/Reconcile/close |
| 1b | (não citado) | **Defeito mais grave que o apontado** | O timer usava `commands.send` (lança em canal fechado). Com `parentScope` externo, `close()` não cancelava timers → exceção não tratada na coroutine → possível crash do processo. | Timers sob `timerScope` cancelado no `close()`; `trySend` |
| 2 | Timestamps ignoram `clock` | **Correto** (nas linhas 24–25, não 26–27) | `IslandActivity` usava `System.currentTimeMillis()` como default; o engine nunca tocava `createdAt/updatedAt`. | Engine define `createdAt` (preservado entre upserts) e `updatedAt` com o relógio injetado; defaults viram `0L` |
| 3 | "Bug" de ciclo de vida na `MainActivity` | **Incorreto como bug** | `renderEventSettings()` também é chamado pelos botões, e os switches leem `SharedPreferences` na recriação: nada se perde na rotação. O engine **não estava instanciado em lugar nenhum**, então não havia estado a perder. | Mesmo assim, boa decisão de projeto: `EdgeIslandApp` (Application) é dona do engine |
| 3b | (não citado) | **Lacuna real** | Os switches mudavam preferências mas **nunca chamavam `refreshPolicies()`**, então uma atividade já exibida não sumia ao desativar o evento. | Switches e "ativar/desativar todos" chamam `refreshPolicies()` |
| 4 | `systemUiSeen` pode confundir pacotes | **Plausível, baixa severidade hoje** | Sem hooks na M002, o pior caso é uma linha de log a mais; a exceção seria capturada pelo `try/catch`. Não se sabe se o framework entrega callbacks de pacotes fora do escopo [?]. | `SYSTEMUI_PACKAGE_READY` agora registra `anchorFound` (classe `SystemUIApplication` existe no loader?). Instalar hooks só com âncora confirmada e uma vez (M003) |
| 5a | Faltam `ActivityPayload` tipado e `AccentPalette` | **Verdadeiro, mas é escolha, não defeito** | O modelo só tem título/subtítulo. A forma do payload deve ser ditada pelo Renderer e pelos adapters (M004); fixar agora tende a gerar retrabalho. Não há registro aqui do "comitê" citado. | Adiado; fácil de adicionar quando o adapter de mídia começar |
| 5b | Faltam `DiagnosticRingBuffer` e Laboratório | **Laboratório: feito. Buffer: ressalva** | O buffer no Core **não enxerga** os logs do módulo (rodam no processo do SystemUI), então não elimina o logcat/log do Vector sem o IPC da M002/M003. | Laboratório da Ilha na tela; buffer fica para junto do IPC |
| 5c | Falta `kotlinx-coroutines-test` e teste do engine | **Correto** | Só o `ActivityArbiter` tinha teste. | `ActivityEngineTest` (8 testes, tempo virtual) |

## Achado adicional (não apontado)

`delay()` usa relógio monotônico e `clock()` padrão é de parede. Se o timer acordasse antes de `clock() >= expiry`, o `Expire`
era descartado e a atividade ficava presa até outro comando. Agora `handleExpire` **rearma** o timer nesse caso.

## O que continua sem verificação [?]

- Compilação e execução dos testes (aguarda o CI).
- Comportamento do Laboratório no Edge 30.
- Resultado da validação do M001 (`MODULE_LOADED`, `SYSTEMUI_PACKAGE_*`) — ainda não recebi o log.
