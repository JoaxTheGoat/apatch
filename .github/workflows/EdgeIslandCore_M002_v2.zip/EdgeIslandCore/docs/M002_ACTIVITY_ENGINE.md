# M002 — Activity Engine

Status: **v2 — corrigida após auditoria (ver `AUDIT_M002.md`); ainda não compilada nem executada**.

## Componentes implementados

- `engine/ActivityModels.kt`: tipos de atividade, persistência, comandos e estado renderizável.
- `engine/EventPolicy.kt`: catálogo estável de eventos e políticas.
- `engine/DefaultEventMapping.kt`: mapeamento padrão dos tipos de atividade para eventos configuráveis.
- `engine/ActivityArbiter.kt`: escolhe a apresentação sem destruir as atividades secundárias.
- `engine/ActivityEngine.kt`: Registry serializado por `Channel`, consumidor único e publicação por `StateFlow`.
- `EventPolicyPreferences.kt`: persistência de preferências individuais em `SharedPreferences`.
- `MainActivity.kt`: interface nativa para ativar/desativar cada evento e ativar/desativar todos.
- `app/src/test/.../ActivityArbiterTest.kt`: testes unitários iniciais de preempção e expiração.

## Regras atuais

1. Cada atividade é identificada por `activityId`; `Upsert` atualiza a mesma atividade em vez de criar duplicatas.
2. `Dismiss` remove somente o ID solicitado.
3. Atividades persistentes continuam no Registry quando cobertas por eventos transitórios.
4. Atividade transitória só preempta uma persistente se `canInterrupt=true` e sua prioridade superar a prioridade da persistente principal.
5. Atividade transitória com `expiresAtMillis` é removida ao expirar; o estado é recalculado e a atividade subjacente volta a ser principal.
6. `EventManager` filtra eventos desativados antes de serem apresentados. Uma submissão desativada remove a mesma atividade identificada pelo ID; `refreshPolicies()` reconcilia o Registry depois de uma alteração de preferências e remove atividades que ficaram desativadas.
7. Preferências do Event Manager são locais e sobrevivem ao fechamento/reinício do app.
8. Desativar um evento não desativa o recurso Android correspondente nem revoga permissões do sistema.

## Limites deliberados desta entrega

- A UI de configurações persiste as opções, mas os adapters Android ainda não estão ligados ao Engine.
- Não há Renderer/overlay, serviço em primeiro plano, IPC ou hook de modificação.
- Não há painel de diagnóstico em tempo real nem Laboratório visual nesta entrega.
- `EventPolicy` já prevê prioridade, TTL, capacidade de interrupção e modo de apresentação; a UI atual expõe somente enabled/disabled.
- Eventos específicos (ex.: carregador conectado vs. desconectado) podem usar `IslandActivity.eventKey` para selecionar a política correta.
- A integração do engine com ciclo de vida do processo/app e adapters será feita nas etapas seguintes.

## Validação pendente

- Compilar `assembleDebug` e executar os testes JUnit no CI/Android Studio.
- Instalar no Edge 30 e verificar persistência das opções.
- Conferir visualmente que todos os switches respondem e que o app abre.
- Somente depois ligar adapters reais.

## Mudanças da v2

- Um timer de expiração por atividade, cancelado em Dismiss/Clear/Reconcile/close; `trySend` evita exceção em canal fechado.
- `createdAtMillis`/`updatedAtMillis` definidos pelo engine com o relógio injetado; `createdAt` preservado entre upserts.
- Falhas em política/mapeamento são capturadas e enviadas a `onError`; o actor continua vivo.
- `EdgeIslandApp` guarda engine e preferências; a Activity só os usa.
- Laboratório da Ilha na tela (mídia, chamada, carregador, notificação) para exercitar prioridade, preempção e expiração.
- `ActivityEngineTest`: expiração exata, timer único, preservação de `createdAt`, preempção, evento desativado, falha isolada, `close()`.
