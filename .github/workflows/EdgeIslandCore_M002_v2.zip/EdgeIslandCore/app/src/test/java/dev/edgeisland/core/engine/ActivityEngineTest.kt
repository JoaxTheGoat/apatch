package dev.edgeisland.core.engine

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Relógio do engine = relógio virtual do teste, para que delay() e clock() andem juntos. */
@OptIn(ExperimentalCoroutinesApi::class)
class ActivityEngineTest {
    private fun TestScope.newEngine(
        manager: EventManager = EventManager { EventPolicy() },
        onError: (Throwable) -> Unit = {}
    ) = ActivityEngine(
        eventManager = manager,
        clock = { testScheduler.currentTime },
        parentScope = this,
        onError = onError
    )

    private fun volume(persistence: ActivityPersistence = ActivityPersistence.TRANSIENT) = IslandActivity(
        activityId = "volume", kind = ActivityKind.VOLUME, title = "Volume", persistence = persistence
    )

    private val ttl3s = EventManager { EventPolicy(ttlMillis = 3_000) }

    @Test fun upsertPublishesPrimaryActivity() = runTest {
        val engine = newEngine()
        try {
            engine.upsert(IslandActivity("media", ActivityKind.MEDIA, "Música"))
            runCurrent()
            assertEquals("media", engine.state.value.primary?.activityId)
        } finally { engine.close() }
    }

    @Test fun transientExpiresExactlyAtTtl() = runTest {
        val engine = newEngine(ttl3s)
        try {
            engine.upsert(volume())
            runCurrent()
            assertEquals("volume", engine.state.value.primary?.activityId)

            advanceTimeBy(2_999); runCurrent()
            assertEquals("volume", engine.state.value.primary?.activityId)

            advanceTimeBy(1); runCurrent()
            assertNull(engine.state.value.primary)
            assertEquals(0, engine.pendingExpiryTimers())
        } finally { engine.close() }
    }

    @Test fun repeatedUpsertKeepsSingleTimerExtendsLifeAndPreservesCreatedAt() = runTest {
        val engine = newEngine(ttl3s)
        try {
            repeat(15) { engine.upsert(volume()) }
            runCurrent()
            assertEquals(1, engine.pendingExpiryTimers())

            advanceTimeBy(2_000); runCurrent()
            engine.upsert(volume()); runCurrent()
            val refreshed = engine.state.value.primary!!
            assertEquals(0L, refreshed.createdAtMillis)
            assertEquals(2_000L, refreshed.updatedAtMillis)

            advanceTimeBy(1_500); runCurrent() // t=3500: o timer antigo (3000) não pode matar a atividade
            assertEquals("volume", engine.state.value.primary?.activityId)

            advanceTimeBy(1_500); runCurrent() // t=5000
            assertNull(engine.state.value.primary)
        } finally { engine.close() }
    }

    @Test fun dismissCancelsTimerAndRecreatedPersistentActivityIsNotRemoved() = runTest {
        val engine = newEngine(ttl3s)
        try {
            engine.upsert(volume()); runCurrent()
            engine.dismiss("volume"); runCurrent()
            assertEquals(0, engine.pendingExpiryTimers())

            engine.upsert(volume(ActivityPersistence.PERSISTENT)); runCurrent()
            advanceTimeBy(5_000); runCurrent()
            assertEquals("volume", engine.state.value.primary?.activityId)
        } finally { engine.close() }
    }

    @Test fun interruptingTransientPreemptsThenPersistentReturns() = runTest {
        val manager = EventManager { event ->
            if (event == IslandEvent.CHARGER_CONNECTED)
                EventPolicy(priority = 90, ttlMillis = 3_000, canInterrupt = true)
            else EventPolicy()
        }
        val engine = newEngine(manager)
        try {
            engine.upsert(IslandActivity("media", ActivityKind.MEDIA, "Música", priority = 50))
            engine.upsert(
                IslandActivity("charger", ActivityKind.CHARGING, "Carregando",
                    persistence = ActivityPersistence.TRANSIENT)
            )
            runCurrent()
            assertEquals("charger", engine.state.value.primary?.activityId)
            assertEquals(listOf("media"), engine.state.value.secondary.map { it.activityId })

            advanceTimeBy(3_000); runCurrent()
            assertEquals("media", engine.state.value.primary?.activityId)
            assertTrue(engine.state.value.secondary.isEmpty())
        } finally { engine.close() }
    }

    @Test fun disabledEventIsRejectedAndRemovedOnRefresh() = runTest {
        var mediaEnabled = true
        val manager = EventManager { event ->
            EventPolicy(enabled = !(event == IslandEvent.MEDIA && !mediaEnabled))
        }
        val engine = newEngine(manager)
        try {
            assertTrue(engine.upsert(IslandActivity("media", ActivityKind.MEDIA, "Música")))
            runCurrent()
            assertEquals("media", engine.state.value.primary?.activityId)

            mediaEnabled = false
            engine.refreshPolicies(); runCurrent()
            assertNull(engine.state.value.primary)
            assertFalse(engine.upsert(IslandActivity("media", ActivityKind.MEDIA, "Música")))
        } finally { engine.close() }
    }

    @Test fun failingPolicyIsReportedAndEngineKeepsWorking() = runTest {
        val errors = mutableListOf<Throwable>()
        val manager = EventManager { event ->
            if (event == IslandEvent.TORCH) throw IllegalStateException("boom") else EventPolicy()
        }
        val engine = newEngine(manager) { errors += it }
        try {
            assertFalse(engine.upsert(IslandActivity("torch", ActivityKind.TORCH, "Lanterna")))
            assertEquals(1, errors.size)

            assertTrue(engine.upsert(IslandActivity("media", ActivityKind.MEDIA, "Música")))
            runCurrent()
            assertEquals("media", engine.state.value.primary?.activityId)
        } finally { engine.close() }
    }

    @Test fun closeCancelsPendingTimersWithoutCrashing() = runTest {
        val engine = newEngine(ttl3s)
        engine.upsert(volume()); runCurrent()
        assertEquals(1, engine.pendingExpiryTimers())

        engine.close()
        advanceUntilIdle() // com o bug antigo, o timer enviava para um canal fechado e falhava o teste
        assertFalse(engine.upsert(volume()))
    }
}
