package dev.edgeisland.core.engine

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap

/**
 * Single-consumer actor: all registry mutations are serialized through one Channel.
 * The engine is deliberately independent of Xposed, Android views and adapters.
 *
 * Invariants:
 *  - at most one expiry timer per activityId (a new schedule cancels the previous one);
 *  - timers are cancelled on Dismiss / ClearTransient / policy removal / close();
 *  - a failing command is reported through [onError] and never stops the actor;
 *  - createdAtMillis / updatedAtMillis always come from the injected [clock].
 */
class ActivityEngine(
    private val eventManager: EventManager,
    private val eventForActivity: (IslandActivity) -> IslandEvent? = { activity ->
        activity.eventKey?.let(IslandEvent::fromKey) ?: DefaultEventMapping.eventFor(activity.kind)
    },
    private val clock: () -> Long = System::currentTimeMillis,
    parentScope: CoroutineScope? = null,
    private val onError: (Throwable) -> Unit = {}
) : Closeable {
    private val ownedJob = SupervisorJob()
    private val scope = parentScope ?: CoroutineScope(ownedJob + Dispatchers.Default)

    /** Timers live under their own child job so close() can cancel them even with a caller-owned scope. */
    private val timerScope = CoroutineScope(scope.coroutineContext + SupervisorJob(scope.coroutineContext[Job]))
    private val expiryJobs = ConcurrentHashMap<String, Job>()

    private val commands = Channel<ActivityCommand>(Channel.UNLIMITED)
    private val registry = linkedMapOf<String, IslandActivity>()
    private val mutableState = MutableStateFlow(IslandUiState())
    val state: StateFlow<IslandUiState> = mutableState.asStateFlow()

    private val worker: Job = scope.launch {
        for (command in commands) {
            try {
                handle(command)
                publish()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reportError(e)
            }
        }
    }

    private fun handle(command: ActivityCommand) {
        when (command) {
            is ActivityCommand.Upsert -> handleUpsert(command.activity)
            is ActivityCommand.Dismiss -> removeActivity(command.activityId)
            is ActivityCommand.Expire -> handleExpire(command)
            ActivityCommand.ClearTransient ->
                removeWhere { it.persistence == ActivityPersistence.TRANSIENT }
            ActivityCommand.ReconcilePolicies ->
                removeWhere { activity ->
                    val event = eventForActivity(activity)
                    event != null && !eventManager.isEnabled(event)
                }
        }
    }

    private fun handleUpsert(activity: IslandActivity) {
        val event = eventForActivity(activity)
        if (event != null && !eventManager.isEnabled(event)) {
            removeActivity(activity.activityId)
            return
        }
        val policy = event?.let(eventManager::policyFor)
        val now = clock()
        val existing = registry[activity.activityId]
        val normalized = applyPolicy(activity, policy, now).copy(
            createdAtMillis = existing?.createdAtMillis ?: now,
            updatedAtMillis = now
        )
        registry[normalized.activityId] = normalized
        scheduleExpiry(normalized)
    }

    private fun handleExpire(command: ActivityCommand.Expire) {
        val current = registry[command.activityId] ?: return
        if (current.persistence != ActivityPersistence.TRANSIENT ||
            current.expiresAtMillis != command.expectedExpiry
        ) return // timer obsoleto: a atividade foi atualizada ou mudou de tipo
        if (command.expectedExpiry <= clock()) {
            removeActivity(command.activityId)
        } else {
            // delay() usa relógio monotônico e clock() pode ser de parede: se acordou cedo, rearma.
            scheduleExpiry(current)
        }
    }

    /**
     * Returns false when the event is disabled, the engine is closed, or the policy lookup failed.
     * A disabled event also dismisses any activity already shown with the same id.
     */
    fun upsert(activity: IslandActivity): Boolean = try {
        val event = eventForActivity(activity)
        if (event != null && !eventManager.isEnabled(event)) {
            commands.trySend(ActivityCommand.Dismiss(activity.activityId))
            false
        } else {
            commands.trySend(ActivityCommand.Upsert(activity)).isSuccess
        }
    } catch (e: Exception) {
        reportError(e)
        false
    }

    private fun applyPolicy(activity: IslandActivity, policy: EventPolicy?, now: Long): IslandActivity {
        if (policy == null) return activity
        val expiry = if (activity.persistence == ActivityPersistence.TRANSIENT && policy.ttlMillis != null) {
            now + policy.ttlMillis.coerceAtLeast(0L)
        } else activity.expiresAtMillis
        return activity.copy(
            priority = policy.priority ?: activity.priority,
            expiresAtMillis = expiry,
            canInterrupt = policy.canInterrupt ?: activity.canInterrupt,
            presentationMode = policy.presentationMode ?: activity.presentationMode
        )
    }

    fun dismiss(activityId: String): Boolean =
        commands.trySend(ActivityCommand.Dismiss(activityId)).isSuccess

    fun clearTransient(): Boolean =
        commands.trySend(ActivityCommand.ClearTransient).isSuccess

    /** Call after preferences change to immediately remove now-disabled activities. */
    fun refreshPolicies(): Boolean =
        commands.trySend(ActivityCommand.ReconcilePolicies).isSuccess

    /** Visible for tests: number of live expiry timers (must never exceed the number of transient activities). */
    internal fun pendingExpiryTimers(): Int = expiryJobs.size

    private fun scheduleExpiry(activity: IslandActivity) {
        cancelExpiry(activity.activityId)
        val expiry = activity.expiresAtMillis ?: return
        if (activity.persistence != ActivityPersistence.TRANSIENT) return
        expiryJobs[activity.activityId] = timerScope.launch {
            delay((expiry - clock()).coerceAtLeast(0L))
            // trySend: nunca lança se o canal já foi fechado (close() concorrente).
            commands.trySend(ActivityCommand.Expire(activity.activityId, expiry))
        }
    }

    private fun cancelExpiry(activityId: String) {
        expiryJobs.remove(activityId)?.cancel()
    }

    private fun removeActivity(activityId: String) {
        registry.remove(activityId)
        cancelExpiry(activityId)
    }

    private fun removeWhere(predicate: (IslandActivity) -> Boolean) {
        val iterator = registry.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (predicate(entry.value)) {
                iterator.remove()
                cancelExpiry(entry.key)
            }
        }
    }

    private fun publish() {
        val now = clock()
        removeWhere {
            it.persistence == ActivityPersistence.TRANSIENT &&
                it.expiresAtMillis != null && it.expiresAtMillis <= now
        }
        mutableState.value = ActivityArbiter.select(registry.values, now)
    }

    private fun reportError(error: Throwable) {
        try {
            onError(error)
        } catch (_: Throwable) {
            // O relato de erro nunca pode derrubar o engine.
        }
    }

    override fun close() {
        commands.close()
        timerScope.cancel()
        worker.cancel()
        if (parentScopeIsOwned()) ownedJob.cancel()
    }

    // The engine only cancels the scope it created; parent scopes remain caller-owned.
    private fun parentScopeIsOwned(): Boolean = scope.coroutineContext[Job] === ownedJob
}
