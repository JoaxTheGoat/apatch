package dev.edgeisland.core

import android.app.Application
import android.util.Log
import dev.edgeisland.core.engine.ActivityEngine

/**
 * Dono único do estado de processo: preferências e ActivityEngine.
 * A Activity pode ser recriada (rotação etc.) sem perder as atividades ativas.
 * Quando houver adapters/serviços, eles usam esta mesma instância.
 */
class EdgeIslandApp : Application() {
    lateinit var eventPreferences: EventPolicyPreferences
        private set
    lateinit var engine: ActivityEngine
        private set

    override fun onCreate() {
        super.onCreate()
        eventPreferences = EventPolicyPreferences(this)
        engine = ActivityEngine(
            eventManager = eventPreferences.eventManager(),
            onError = { Log.w("EdgeIsland", "ENGINE_ERROR", it) }
        )
    }
}
