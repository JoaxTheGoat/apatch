package dev.edgeisland.core.engine

/**
 * Domain model for the Edge Island activity engine.
 * This package has no Android or libxposed dependency.
 */
enum class ActivityKind {
    MEDIA, CALL, TIMER, STOPWATCH, NAVIGATION, NOTIFICATION,
    CHARGING, BLUETOOTH, WIFI, MOBILE_DATA, BATTERY_ALERT,
    VOLUME, BRIGHTNESS, TORCH, DOWNLOAD, CUSTOM
}

enum class ActivityPersistence { PERSISTENT, TRANSIENT }

enum class PresentationMode { AUTOMATIC, COMPACT, EXPANDED }

data class IslandActivity(
    val activityId: String,
    val kind: ActivityKind,
    val title: String,
    val subtitle: String? = null,
    val priority: Int = 0,
    val persistence: ActivityPersistence = ActivityPersistence.PERSISTENT,
    /** Preenchidos pelo ActivityEngine com o relógio injetado; valores do chamador são ignorados. */
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L,
    val expiresAtMillis: Long? = null,
    val canInterrupt: Boolean = false,
    /** Optional event-policy override for subtypes such as charger connected/disconnected. */
    val eventKey: String? = null,
    val presentationMode: PresentationMode = PresentationMode.AUTOMATIC
)

sealed interface ActivityCommand {
    data class Upsert(val activity: IslandActivity) : ActivityCommand
    data class Dismiss(val activityId: String) : ActivityCommand
    data class Expire(val activityId: String, val expectedExpiry: Long) : ActivityCommand
    data object ClearTransient : ActivityCommand
    data object ReconcilePolicies : ActivityCommand
}

data class IslandUiState(
    val primary: IslandActivity? = null,
    val secondary: List<IslandActivity> = emptyList(),
    val activities: List<IslandActivity> = emptyList(),
    val generatedAtMillis: Long = 0L
)
