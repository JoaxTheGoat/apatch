import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.edgeisland.core"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.edgeisland.core"
        minSdk = 32
        targetSdk = 36
        versionCode = 2
        versionName = "0.1.1-m001"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Kotlin 2.2+: o bloco kotlinOptions{} é erro de compilação; usar compilerOptions.
kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.JVM_17
    }
}

dependencies {
    // API usada apenas para compilar o entry point; fornecida pelo framework no runtime.
    // Nunca empacotar no APK (compileOnly).
    compileOnly("io.github.libxposed:api:102.0.0")
}
