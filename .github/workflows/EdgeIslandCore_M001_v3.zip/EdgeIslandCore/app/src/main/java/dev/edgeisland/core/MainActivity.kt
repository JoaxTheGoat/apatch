package dev.edgeisland.core

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(0xFFF5F5F5.toInt())
        }

        content.addView(text("Edge Island", 30, true))
        content.addView(text("CORE • MILESTONE 001", 12, true).apply {
            setPadding(0, dp(4), 0, dp(22))
        })

        content.addView(section("Ambiente"))
        content.addView(info("Aplicativo", "Edge Island Core"))
        content.addView(info("Módulo", "libxposed API 102 (escopo estático)"))
        content.addView(info("Framework", "Vector — ativação manual no manager"))
        content.addView(info("Escopo previsto", "com.android.systemui"))

        content.addView(section("Estado desta versão"))
        content.addView(info("Interface", "Painel inicial instalado"))
        content.addView(info("Hooks", "Nenhum hook de modificação ativo"))
        content.addView(info("IPC", "Pendente — próxima milestone"))

        content.addView(section("Próxima etapa"))
        content.addView(text(
            "Compilar, instalar e confirmar no Vector que o entry point foi carregado. " +
            "Depois faremos um hook estritamente observacional, escolhido a partir da " +
            "build real do SystemUI deste aparelho.",
            15, false
        ))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFFF5F5F5.toInt())
            clipToPadding = false
            addView(content)
            // targetSdk 35+ força edge-to-edge: reserva espaço para barras e recorte de tela.
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        }
        setContentView(scroll)
    }

    private fun section(value: String) = text(value, 18, true).apply {
        setPadding(0, dp(24), 0, dp(10))
    }

    private fun info(label: String, value: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
            val title = text(label.uppercase(), 11, true)
            val body = text(value, 15, false)
            addView(title)
            addView(body)
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
            layoutParams = params
        }
    }

    private fun text(value: String, size: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(0xFF171717.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.START
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
