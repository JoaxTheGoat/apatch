# Roadmap

## M001 — Fundação
- [x] Um APK com Activity e entry point libxposed
- [x] API 102 declarada; chamadas conferidas no javadoc 102.0.0
- [x] Escopo estático restrito ao SystemUI
- [x] Diagnóstico de carregamento via log do framework
- [x] Auditoria do scaffold (`docs/AUDIT_M001.md`)
- [ ] Compilar no Android Studio do usuário
- [ ] Instalar e confirmar `MODULE_LOADED` / `SYSTEMUI_PACKAGE_READY` no Vector v2.2

## M002 — Diagnóstico
- Fingerprint da build, versão Android e processo exato.
- Exibir estado local; exportar diagnóstico sem permissões privilegiadas.
- Projetar IPC autenticado (ver AUDIT, seção IPC).
- Painel de estado.

## M003 — Integração SystemUI
- Inventário de classes/métodos reais da build instalada (não presumir nomes).
- Primeiro hook observacional em `onPackageReady`, com id fixo, `exceptionMode` protetivo.
- Validar estabilidade (sem crash/loop do SystemUI) antes de avançar.

## M004 — Dynamic Island
- Renderer, cápsula, motor de atividades (prioridade, duração, urgência, estado, preservação das secundárias).
- Mídia (MediaSession) e notificações (NotificationListener) via APIs públicas primeiro.
- Hooks seletivos só onde APIs públicas não bastarem.

## M005 — Recursos avançados
- Gestos, personalização, animações, sensores/eventos, consumo e desempenho.
- Acabamento: cápsula de mídia preta, capa ao lado, acentos extraídos da arte; Monet nas configurações.
