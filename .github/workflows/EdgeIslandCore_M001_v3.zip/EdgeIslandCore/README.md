# Edge Island Core — Milestone 001 (v0.1.1)

Base de projeto para um único APK Android que combina:
- aplicativo Core (Activity launcher);
- módulo moderno libxposed API 102;
- metadados de módulo e escopo para o Vector;
- diagnóstico inicial, sem modificar o comportamento do SystemUI.

**Estado:** scaffold auditado, **ainda não compilado nem testado no aparelho**.
Veja `docs/AUDIT_M001.md` para o que foi verificado na documentação e o que depende de teste real.

## Dispositivo e ambiente-alvo

- Motorola Edge 30 (`dubai`), PixelOS (Android 17), APatch + ReZygisk, Vector v2.2.
- Desenvolvimento: Windows, Android Studio, JDK 17, Kotlin/Java.
- AGP 8.13.2, Kotlin 2.2.20, Gradle 8.13+, `compileSdk 36` (ajuste se o Android Studio pedir).
- Dependência de compilação: `compileOnly io.github.libxposed:api:102.0.0` (nunca empacotada).

## Abrir e compilar

1. Extraia o ZIP e abra a pasta `EdgeIslandCore` no Android Studio.
2. Aguarde a sincronização do Gradle; instale SDK Platform/Build Tools se solicitado.
3. Gere o APK em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Wrapper local (opcional), no terminal da pasta do projeto:
`gradle wrapper --gradle-version 8.13` e depois `gradlew.bat assembleDebug`.

## Instalação e ativação

1. Instale o APK.
2. No gerenciador do Vector, habilite Edge Island Core.
3. O escopo é **estático**: `staticScope=true` limita o módulo à lista do `scope.list`
   (somente `com.android.systemui`). Confira no manager.
4. Reinicie o SystemUI ou o aparelho conforme o procedimento do Vector.
5. Abra Edge Island Core e confira o painel.
6. Procure no log do Vector (tag `EdgeIsland`):
   - `MODULE_LOADED process=... runtimeApi=102`
   - `SYSTEMUI_PACKAGE_LOADED`
   - `SYSTEMUI_PACKAGE_READY`

**Importante:** instalar o APK não ativa o módulo. O usuário controla ativação e escopo no Vector.

## Segurança nesta milestone

- Sem `android`/`system_server` no escopo; `staticScope=true` impede ampliar o escopo pelo manager.
- Nenhum hook; callbacks apenas registram metadados.
- Sem `WRITE_SECURE_SETTINGS`, Accessibility, overlay ou root próprio.
- Toda a lógica do módulo é protegida por `try/catch Throwable`; falha de log não propaga.
- A UI ainda não recebe telemetria do processo remoto (IPC autenticado em milestone posterior).

## Diagnóstico esperado

- `MODULE_LOADED`: o entry point foi instanciado no processo alvo (inclui `process` e `systemServer`).
- `SYSTEMUI_PACKAGE_LOADED`: callback de pacote alcançado para o SystemUI.
- `SYSTEMUI_PACKAGE_READY`: classloader final do SystemUI pronto — ponto previsto para hooks na M003.
- A ausência de uma mensagem não prova, sozinha, falha do Vector; avaliar o log completo antes de concluir.

## Estrutura

- `app/src/main/java/.../MainActivity.kt`: painel inicial.
- `app/src/main/java/.../xposed/EdgeIslandModule.java`: entry point libxposed.
- `app/src/main/resources/META-INF/xposed/`: `java_init.list`, `module.prop`, `scope.list`.
- `app/src/main/res/values/strings.xml`: nome e descrição do módulo (`android:description`).
- `docs/ROADMAP.md`: sequência de implementação.
- `docs/AUDIT_M001.md`: auditoria, riscos e estratégia incremental.

Este é um scaffold de engenharia, não uma Dynamic Island funcional.
