# Auditoria do scaffold M001

Convenção: **[DOC]** confirmado na documentação oficial; **[IMPL]** verificado lendo o código do projeto;
**[REAL]** só se confirma no aparelho. Nada aqui foi compilado ou executado.

## 1. Correções aplicadas (v2 → v0.1.1)

| # | Problema | Evidência | Correção |
|---|----------|-----------|----------|
| 1 | `kotlinOptions {}` com Kotlin 2.2.20 | [DOC] Kotlin 2.2 transforma o DSL em erro | `kotlin { compilerOptions { jvmTarget = JVM_17 } }` |
| 2 | `staticScope=false` contradizia "escopo somente SystemUI" | [DOC] staticScope indica que o usuário não deve aplicar o módulo fora do escopo | `staticScope=true` |
| 3 | `autoHotReload` em `module.prop` | [DOC] o javadoc lista apenas minApiVersion, targetApiVersion (obrigatórias), staticScope e exceptionMode (opcionais) | chave removida |
| 4 | Sem `android:description` | [DOC] nome/descrição do módulo vêm de `android:label`/`android:description` | `strings.xml` + manifest |
| 5 | `proguard-rules.pro` não referenciado | [IMPL] | `proguardFiles(...)` no release (minify segue desligado) |
| 6 | Diagnóstico sem processo | [DOC] `ModuleLoadedParam` expõe `getProcessName()` e `isSystemServer()` | incluídos em `MODULE_LOADED` |
| 7 | Sem callback de classloader final | [DOC] `onPackageReady` é chamado com o classloader pronto; é o ponto de hooks | `SYSTEMUI_PACKAGE_READY` (só observa) |
| 8 | Edge-to-edge (targetSdk 36) cobria o conteúdo | [IMPL] | tratamento de `WindowInsets` |

Mantido: `minApiVersion=102`. O briefing registra que o Vector v2.2 do aparelho roda módulos do dia a dia;
se o módulo não carregar, o primeiro suspeito a checar no log é a versão de API suportada pelo Vector [REAL].

## 2. API verificada no javadoc 102.0.0 [DOC]

Existem: construtor sem argumentos de `XposedModule`; `onModuleLoaded`, `onPackageLoaded`, `onPackageReady`;
`getFrameworkName/Version/VersionCode`, `getApiVersion`; `log(int,String,String)` e `log(int,String,String,Throwable)`;
`PackageLoadedParam`: `getPackageName`, `isFirstPackage`, `getDefaultClassLoader`, `getApplicationInfo`;
`PackageReadyParam`: `getClassLoader`, `getAppComponentFactory`; `ModuleLoadedParam`: `getProcessName`, `isSystemServer`.

**Não verificado:** se `PackageReadyParam` herda `getPackageName()` de `PackageLoadedParam`. Por isso `onPackageReady`
usa só `getClassLoader()` e filtra por uma flag marcada em `onPackageLoaded`. Confirmar na M003 e trocar pelo nome do pacote.

## 3. Divergências a observar (documentação × implementação × real)

- [DOC] `exceptionMode` aceita `protective|passthrough`, padrão `protective`. Declaramos `protective` explicitamente.
  [REAL] Confirmar no log se o Vector v2.2 respeita o modo.
- [DOC] "Todo pacote carregado no processo dispara callbacks". [IMPL] O módulo filtra por `com.android.systemui`.
  [REAL] Pode haver mais de um `onPackageReady` por processo; a flag é uma aproximação aceitável só para diagnóstico.
- [REAL] `getProcessName()` deve ser `com.android.systemui`; se vier outro processo do mesmo pacote, registrar e decidir.

## 4. Riscos de hooks no SystemUI do Android 17 (hipóteses a verificar, nenhuma confirmada)

1. **Classes e métodos mudam entre builds.** Fazer inventário na própria ROM (dex do SystemUI) antes de qualquer hook; nunca presumir nomes.
2. **Inlining/otimização:** método pequeno pode ser inlined e o hook nunca disparar. A API oferece `deoptimize(Executable)`; usar só se necessário.
3. **Estabilidade:** crash do SystemUI costuma reiniciar o processo, mas loops de crash são possíveis. Manter `protective`, hooks com id fixo e um interruptor de desativação.
4. **Desempenho:** não hookar caminhos quentes (desenho/layout por frame). Preferir eventos discretos.
5. **Compatibilidade de SDK:** Android 17 pode exigir `compileSdk`/`targetSdk` maiores no futuro. Manter 36 até validar; não presumir.
6. **Escopo:** `android`/`system_server` fora do escopo na primeira fase, como definido no briefing.

## 5. IPC (M002)

Antes de criar um canal próprio, avaliar o que a API 102 já provê [DOC]: remote preferences e remote files
(capacidade `PROP_CAP_REMOTE`, consultável via `getFrameworkProperties`), úteis no sentido **Core → processo injetado**
(configuração). Para **SystemUI → Core** (telemetria/eventos) ainda é preciso canal próprio: serviço/provider no Core
com verificação do UID chamador (`Binder.getCallingUid`) e assinatura. Confirmar `PROP_CAP_REMOTE` no Vector v2.2 [REAL].

## 6. Estratégia incremental

1. M001: compilar → instalar → ler `MODULE_LOADED`, `SYSTEMUI_PACKAGE_LOADED`, `SYSTEMUI_PACKAGE_READY` no log.
2. M002: fingerprint, painel, canal de diagnóstico autenticado.
3. M003: inventário real do SystemUI; um único hook observacional, desativável.
4. M004: lógica da ilha com APIs públicas (MediaSession, NotificationListener) e o motor de atividades, testável sem hooks.
5. Só então hooks seletivos, um de cada vez, com teste de estabilidade entre eles.

O motor de atividades (prioridade, duração, urgência, estado, preservação das secundárias) deve ser um módulo puro Kotlin,
sem dependência de Xposed, para ser testado em unidade no Windows.

## 7. Ainda não feito

- Compilação real (sem SDK/rede neste ambiente de revisão) e execução no aparelho.
- Wrapper Gradle (`gradlew`) não incluído; gerar pelo Android Studio.
- Engenharia reversa do Material Capsule 17.3: não iniciada; conclusões só após leitura do código.
