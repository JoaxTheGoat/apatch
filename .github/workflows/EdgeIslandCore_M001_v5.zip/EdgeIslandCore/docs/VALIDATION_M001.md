# Validação do M001 no aparelho

Só depois disto passamos para hooks. Registre o resultado de cada passo; não presumir sucesso sem o log.

## Passos

1. Instale o APK (`adb install -r app-debug.apk`) e abra **Edge Island Core**. O painel deve mostrar aparelho, Android, build e versão do SystemUI.
2. No Vector: ative o módulo e confirme que o escopo mostra **somente** `com.android.systemui` (com `staticScope=true` não deve ser possível adicionar outros).
3. Reinicie o SystemUI (o sistema o relança sozinho) ou o aparelho:
   `adb shell su -c "pkill -f com.android.systemui"` — ou reboot normal.
4. Leia o log (um dos dois, ou ambos):
   - logcat: `adb logcat -s EdgeIsland`
   - log do Vector, no próprio manager.

## Resultado esperado

```
MODULE_LOADED process=com.android.systemui systemServer=false framework=... runtimeApi=102 device=dubai android=... sdk=... build=...
SYSTEMUI_PACKAGE_LOADED package=com.android.systemui ...
SYSTEMUI_PACKAGE_READY classLoader=...
```

## Como interpretar

| Observado | Significa | Próximo passo |
|---|---|---|
| As 3 linhas | Módulo carregado, SystemUI alcançado, classloader final pronto | Liberar M002/M003 |
| Só `MODULE_LOADED` | Carregou, mas os callbacks de pacote não chegaram | Conferir `process=`; verificar escopo e reinício do SystemUI |
| Nenhuma | Módulo não carregou | Conferir ativação/escopo; ver erro do Vector; considerar `minApiVersion` |
| `*_DIAGNOSTIC_FAILED` | Exceção capturada pela proteção | Enviar o stack trace |
| `runtimeApi` ≠ 102 | Vector expõe outra versão da API | Reavaliar `minApiVersion` |

Campos úteis a enviar: linha `MODULE_LOADED` completa (traz processo, framework, versão e fingerprint).

## Resultado desta validação

(preencher) Data: ____  Linhas observadas: ____  Conclusão: ____
