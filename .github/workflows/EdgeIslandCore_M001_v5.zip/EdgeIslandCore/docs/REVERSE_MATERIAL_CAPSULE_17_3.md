# Engenharia reversa — Material Capsule 17.3 (com.pryshedko.mtisland)

Objetivo: entender o produto e a arquitetura para construir o Edge Island **do zero, com código e assets próprios**.
Não copiamos código, animações (Lottie), textos ou ícones, e não mexemos na verificação de licença/Pro do app.

Legenda: **[APK]** observado diretamente no arquivo (manifest, recursos, tabelas do DEX); **[INF]** inferido a partir dessas
evidências; **[?]** não sabemos sem ler o bytecode ou testar em aparelho.

## 0. Método e limites

- Analisado: `AndroidManifest.xml` (decodificado), `res/xml`, `resources.arsc` (textos da interface), tabelas de strings/tipos/métodos/classes
  do `classes.dex` e o esquema do banco Room. Ferramentas: `tools/reverse/axml.py` e `tools/reverse/dexr.py` (escritas para isto).
- **Não** foi feita descompilação do bytecode: o código está ofuscado com R8 (só 14 classes mantêm o nome `com.pryshedko`). Por isso
  não sabemos *como* cada regra é implementada, apenas *quais APIs* são usadas e *quais funções* o produto expõe.
- O app tem proteção PairIP (verificação de licença do Google Play, classes `com.pairip.*`). Não há biblioteca nativa de virtualização no split
  arm64 [APK]; a leitura acima não precisou tocar nela e não será contornada.
- APKs de terceiros podem diferir do que está na Play Store; tratar como retrato desta versão (17.3, versionCode 173, compileSdk 37, minSdk 32, targetSdk 36).

## 1. Conclusão principal

**O Material Capsule não é um módulo Xposed.** [APK] É um app comum que desenha uma cápsula como *overlay* a partir de um
`AccessibilityService` e lê o mundo por `NotificationListenerService`, `MediaSession` e broadcasts públicos. Não há `META-INF/xposed`,
não há metadado de módulo, não há hook.

Consequência para o Edge Island: paridade funcional é possível só com APIs públicas (o que o briefing já manda priorizar). A vantagem
de "integrado ao sistema" vem de **onde a cápsula é desenhada e de quais limites do overlay conseguimos remover** (seção 6).

## 2. Componentes [APK]

| Componente | Função |
|---|---|
| `GlobalActionBarService` (AccessibilityService) | Hospeda a cápsula (usa `WindowManager`), despacha gestos, consulta janelas. Config: `canPerformGestures`, `canRetrieveWindowContent`, `flagRetrieveInteractiveWindows`, `showOnLockScreen=false`. |
| `NotificationService` (NotificationListener) | Lê/cancela notificações; também é a "chave" para listar `MediaSession` ativas. |
| `MainAppActivity` (Compose, Material 3 Expressive) | Configurações e editor de cartões. |
| `CallPermissionActivity`, `WidgetPickerActivity` | Pedido de permissão de ligação; escolha de app widget. |
| 5 widgets 1×1 (`Tap`, `DoubleTap`, `LongPress`, `SwipeLeft`, `SwipeRight`) + `GestureWidgetReceiver` | [INF] Pontos de entrada para disparar os gestos da cápsula de fora (o app cita "mesma lógica do Tasker e Automate"). |
| Banco Room (`MIRepository`) | Persistência de cartões, atalhos, cores e apps de notificação. |
| `App` (+ `pairip`) | Application; licença do Play. |

Bibliotecas [APK]: Jetpack Compose + Material 3 (inclui "expressive"), Lottie (95 animações em `assets/lottie`), Room, Coil, Ktor/OkHttp,
kotlinx.serialization, CameraX + ML Kit (leitor de QR/código de barras), Firebase Analytics, Play Billing 9.1.0, Play Integrity, `skydoves/colorpickerview`.

## 3. APIs do Android realmente usadas [APK]

| Área | Evidência no DEX |
|---|---|
| Gestos | `AccessibilityService.dispatchGesture`, `performGlobalAction`, `getWindows`, `GestureDescription.StrokeDescription(Path,…)` |
| Mídia | `MediaSessionManager.getActiveSessions(ComponentName)` + `OnActiveSessionsChangedListener`; `MediaController` (callback, `getMetadata`, `getPlaybackState`); `TransportControls` play/pause/seekTo/skipToNext/skipToPrevious/sendCustomAction; `PlaybackState.getPosition/getPlaybackSpeed/getCustomActions` |
| Notificações | `getActiveNotifications`, `cancelNotification`, `StatusBarNotification`, `Notification.getSmallIcon/getLargeIcon/getChannelId` |
| Energia | broadcasts `ACTION_POWER_CONNECTED/DISCONNECTED`, `BATTERY_CHANGED`, `POWER_SAVE_MODE_CHANGED`; `BatteryManager.computeChargeTimeRemaining` |
| Bluetooth | broadcasts A2DP / Headset / LE Audio / HearingAid `CONNECTION_STATE_CHANGED`, `adapter.STATE_CHANGED`; `BluetoothDevice.getBluetoothClass` |
| Rede / modo avião | `ConnectivityManager.registerNetworkCallback`, `NetworkCapabilities`; `AIRPLANE_MODE` |
| Som | `AudioManager` volume/ringer; `VOLUME_CHANGED_ACTION`, `STREAM_MUTE_CHANGED_ACTION`; `INTERRUPTION_FILTER_CHANGED` |
| Brilho | `Settings.System.putInt/canWrite`, `Settings.Global.getFloat`, `ContentObserver` (`screen_brightness`, `screen_brightness_mode`) |
| Lanterna | `CameraManager.setTorchMode`, `turnOnTorchWithStrengthLevel`, `TorchCallback` |
| Tela | `DisplayManager` + listener, `Display.getRoundedCorner/getRotation`, `DisplayCutout.getBoundingRects/getCutoutPath`, `WindowMetrics` |
| Widgets | `AppWidgetHost` (allocate/bind/createView/startListening), `AppWidgetManager.getInstalledProviders` |
| Animação | `Choreographer`, `ValueAnimator` (+ escala de duração), `RenderEffect` (blur e shader em runtime) |
| Háptico | `VibrationEffect.Composition` (primitivas), `VibratorManager` |
| Outros | `ClipboardManager`, `KeyguardManager`, `PowerManager`, `ActivityManager.getAppTasks`, `PopupWindow` |

Ausentes [APK]: `TelecomManager`, `BluetoothAdapter` direto, `MediaProjection`, `SensorManager` além de `getDefaultSensor`. Ligações, portanto, são
[INF] derivadas de notificações (textos "Incoming call", "Ongoing call", "Screening an incoming call") e a ação "Make Call" usa `ACTION_CALL` + contatos.

## 4. Funcionalidades do produto (pelos textos da interface) [APK]

- **Modos de cápsula:** independente; "parte da câmera" (usa o recorte); abaixo da barra de status; sempre ativa; mini cápsula; modo relógio. Ajuste de X/Y, largura/altura, opacidade, borda, raio da forma expandida, alinhamento e escala da mini cápsula, gradiente do recorte, "zona morta" no topo (reserva o gesto da aba de notificações).
- **Eventos (mini cápsula):** carregamento (USB/sem fio, ligado/desligado), Bluetooth ligado/desligado/fones conectados, Wi-Fi conectado/desconectado, modo avião, mudança toque/vibrar/silencioso, brilho adaptativo, lanterna, timer/cronômetro do relógio, mídia tocando.
- **Cartões** (tipos `CARD, CLOCK, NOTIFICATION, QR, WIDGET`): player de mídia (tamanho completo ou compacto), sliders de volume e brilho, atalhos (app, contato/ligação, intent, broadcast), widget de terceiros, leitor de QR, relógio.
- **Notificações dentro da cápsula:** só texto, por app permitido; progresso extraído da notificação (downloads); dispensar com deslize para cima.
- **Gestos:** toque, toque duplo, toque longo, deslize esquerda/direita na cápsula; gestos do player sem expandir; "dynamic cards gesture"; ação de rolar ao topo.
- **Personalização:** cores (combinações dia/noite, 3 cores do player a partir da capa), perfis por tela/dispositivo (com compartilhamento), bounce (nenhum/normal/alto/máximo), duração e velocidade de animação, reduzir animações, háptico, depuração da interface.
- **Comercial:** recursos "Pro" com Play Billing; Play Integrity. Fora do escopo do Edge Island (uso pessoal).
- **Dependências externas:** otimizado só para o Google Relógio; integração com o app MaterialPods (bateria de fones por broadcast).

## 5. Modelo de dados [APK: esquema Room]

`CardItem` (posição, tipo, gesto, parâmetros de slider/atalhos/player minimizado), `Shortcut` (tipo, escala, vibração, forma, ícone,
contato, intent/extras/broadcast), `ColorCombination{One,OneDayNight,Single,Player,…}`, `NotificationApp`, `UnselectedApp`.
Modelos em memória (nomes preservados nos `toString`): `GlobalCapsuleSettings`, `CapsuleBehaviorParams`, `CapsuleLayout`, `CapsuleColorSettings`,
`CapsuleContentCard/Event/Notification`, `CapsuleSubContent`, `CurrentMediaInformation`, `BatteryInformation`, `ClockNotificationItem`,
`ProgressNotificationItem`, `SimplifiedNotificationItem`, `PlayerUiState/Actions/Colors/Cover/Progress`, `ScreenProfileSettings`, `OperatingMode`.

Leitura útil: o app separa **conteúdo** (evento, cartão, notificação, subconteúdo) de **layout/aparência** (esquerda/direita, forma, cor).
Boa ideia a manter no Edge Island.

## 6. Limites do modelo "overlay por acessibilidade" (onde o Edge Island pode ser melhor)

Cada item vem do próprio app ou do desenho da plataforma; o ganho com SystemUI/libxposed é **hipótese a validar [?]**.

| Limite observado | Evidência | Possível melhoria no Edge Island |
|---|---|---|
| Depende de serviço de acessibilidade, que o sistema pode desligar | texto: "necessário caso o serviço sofra problemas ou seja parado"; permissão `WRITE_SECURE_SETTINGS` | Sem acessibilidade: o renderer vive no SystemUI (já é do sistema) |
| Não aparece na tela de bloqueio | `showOnLockScreen=false` | Integrar ao keyguard/AOD do SystemUI |
| Reserva "zona morta" para não brigar com a aba de notificações | texto da configuração | Conviver nativamente com a janela da barra de status |
| Restrições de acessibilidade: configurações restritas (sideload) e modo Proteção Avançada | `QUERY_ADVANCED_PROTECTION_MODE` [APK]; propósito [INF] | Menos dependência de permissões sensíveis |
| Só notificações de texto; relógio só do Google Relógio | textos | Fontes mais genéricas (MediaSession/Notification category/ongoing) |
| Muitas permissões | 25+ no manifest, incl. `QUERY_ALL_PACKAGES`, `READ_CONTACTS`, `CALL_PHONE`, `CAMERA` | Pedir cada uma só quando o recurso correspondente chegar |

Riscos de ir para o SystemUI [?]: estabilidade (crash reinicia o processo), recursos/Compose fora do APK do módulo, classes que mudam entre builds do PixelOS,
desempenho por frame. Ver `AUDIT_M001.md`, seção 4.

## 7. Arquitetura-alvo proposta (a partir do briefing + achados)

```
Core (APK único, ícone único)
 ├─ Engine (Kotlin puro, testável no Windows)
 │    ActivityStore: lista de atividades com {id, tipo, prioridade, urgência, estado, expansível, expira em}
 │    Policy: escolhe a atividade em foco, preserva as secundárias, alterna sem perder estado
 ├─ Adapters (APIs públicas; um por fonte, cada um atrás de uma interface)
 │    Media · Notification(+progresso, ligação, timer) · Charging · Bluetooth · Network · Ringer · Brightness · Torch · Clipboard…
 ├─ IPC autenticado  ──────────────►  SystemUI (módulo libxposed, escopo estático)
 │    Engine → estado renderizável               Renderer da cápsula/cartões
 │    Renderer → eventos (toque, gesto, ação)     hooks mínimos: ponto de ancoragem + recorte
 └─ UI de configurações (Material You/Monet)
```

Decisão em aberto [precisa do usuário]: onde fica o **Renderer** na primeira versão visível —
(A) no SystemUI via libxposed desde o início (melhor integração, mais risco), ou
(B) como overlay do Core (permissão de sobreposição, menos integrado) enquanto o inventário do SystemUI (M003) amadurece, migrando depois.
A Engine e os Adapters são idênticos nos dois caminhos, então nada do trabalho de M002/M004 é descartado.

## 8. Impacto no roadmap

- **M002:** acrescentar ao diagnóstico a lista de permissões/estado de cada Adapter e definir o contrato `Activity` (tipo, prioridade, urgência, estado).
- **M003:** além do hook observacional, inventariar no SystemUI real: janela da barra de status, recorte da câmera, keyguard/AOD (usar `tools/reverse/dexr.py` no dex do SystemUI da ROM).
- **M004:** Engine + 3 adapters em ordem de custo/benefício: Mídia → Carregamento → Notificação (inclui timer/ligação/progresso). Só então Bluetooth, rede, toque/vibrar, lanterna, QR, widgets.
- Manter os não-objetivos: Pro/Billing/Integrity/Analytics do app original não entram.

## 9. O que ainda não sabemos [?]

- Como a Engine do app prioriza eventos simultâneos (precisaria de leitura do bytecode ou testes de comportamento).
- Tipo exato da janela (`TYPE_ACCESSIBILITY_OVERLAY` é a hipótese forte: o texto do app diz que a permissão serve "para desenhar elementos sobre a UI do sistema").
- Formato dos arquivos `assets/lottie/*.bin` (não necessário para o Edge Island, que terá animações próprias).
- Comportamento real no PixelOS Android 17 do Edge 30: só testando o app no aparelho.
