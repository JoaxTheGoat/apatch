# Desenho do IPC (rascunho para a M002)

Status: **proposta**, nada implementado. Itens [?] dependem de verificação no aparelho ou na documentação.

## Dois sentidos, dois problemas

1. **Core → processo injetado (SystemUI): configuração e comandos.**
   A API 102 oferece remote preferences e remote files geridos pelo framework (capacidade `PROP_CAP_REMOTE`, consultável por
   `getFrameworkProperties`) — confirmado no javadoc. O lado do app (Core) escreve por um serviço da biblioteca `libxposed/service`
   (citada na documentação do LSPosed). [?] Confirmar se o Vector v2.2 expõe a capacidade e qual é a dependência exata.
2. **SystemUI → Core: telemetria e eventos.** Não há canal pronto. Proposta: `ContentProvider` ou serviço *bound* no Core, chamado a partir do SystemUI.

## Autenticação (requisito do briefing)

Um app qualquer não pode se passar pelo SystemUI nem ler/alterar o estado do Core.

- Verificar o chamador no Core com `Binder.getCallingUid()`: o UID deve pertencer ao pacote `com.android.systemui` **e** esse pacote deve ser de sistema
  (`ApplicationInfo.FLAG_SYSTEM`). [?] Confirmar na ROM qual UID o SystemUI usa e se `getPackagesForUid` o retorna como esperado.
- Segredo compartilhado por instalação (token aleatório gerado pelo Core), entregue ao módulo pelo canal Core → SystemUI (item 1) e exigido
  em toda chamada do sentido 2. Rotacionável. Não vai em intent nem em log.
- Mensagens versionadas e com validação rígida de tamanho/tipo; nada de desserialização de objetos arbitrários.
- Falha de autenticação: ignorar e registrar contagem, sem resposta detalhada.

## Regras de robustez

- O módulo nunca bloqueia thread do SystemUI esperando o Core: chamadas assíncronas, com timeout e *circuit breaker*.
- Core fora do ar não pode afetar o SystemUI.
- Dados mínimos: IDs e estado da atividade, nada de conteúdo de notificação na M002.

## Pontos a decidir após a validação do M001

- Obter um `Context` no SystemUI sem API oculta frágil (candidato: o que o hook de M003 já tiver em mãos). [?]
- Se a abordagem (B) for mantida (renderer no Core), o sentido SystemUI → Core pode ficar reduzido a diagnóstico, e o fluxo principal
  (Adapters → Engine → Renderer) roda inteiro dentro do Core.
