package dev.edgeisland.core.xposed;

import android.os.Build;
import android.util.Log;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * Entry point libxposed (API 102).
 *
 * M001 é deliberadamente observacional: não instala hooks nem altera o SystemUI.
 * Todas as chamadas abaixo foram conferidas no javadoc oficial da API 102.0.0.
 *
 * Ciclo de callbacks usado aqui:
 *  - onModuleLoaded : uma vez por processo; identifica processo e framework.
 *  - onPackageLoaded: pacote carregado (ApplicationInfo / classloader padrão).
 *  - onPackageReady : classloader final pronto (AppComponentFactory). É este o
 *                     ponto previsto para instalar hooks a partir da M003.
 */
public final class EdgeIslandModule extends XposedModule {
    private static final String TAG = "EdgeIsland";
    private static final String SYSTEMUI = "com.android.systemui";

    /** Marcado quando o pacote SystemUI passou por onPackageLoaded neste processo. */
    private volatile boolean systemUiSeen = false;

    public EdgeIslandModule() {
        super();
    }

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        super.onModuleLoaded(param);
        try {
            emit(Log.INFO, "MODULE_LOADED"
                    + " process=" + param.getProcessName()
                    + " systemServer=" + param.isSystemServer()
                    + " framework=" + getFrameworkName()
                    + " frameworkVersion=" + getFrameworkVersion()
                    + " frameworkVersionCode=" + getFrameworkVersionCode()
                    + " runtimeApi=" + getApiVersion()
                    + " device=" + Build.DEVICE
                    + " android=" + Build.VERSION.RELEASE
                    + " sdk=" + Build.VERSION.SDK_INT
                    + " build=" + Build.FINGERPRINT);
        } catch (Throwable error) {
            emitError("MODULE_LOADED_DIAGNOSTIC_FAILED", error);
        }
    }

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {
        super.onPackageLoaded(param);
        try {
            String packageName = param.getPackageName();
            if (SYSTEMUI.equals(packageName)) {
                systemUiSeen = true;
                emit(Log.INFO, "SYSTEMUI_PACKAGE_LOADED"
                        + " package=" + packageName
                        + " firstPackage=" + param.isFirstPackage()
                        + " defaultClassLoader=" + param.getDefaultClassLoader().getClass().getName());
            }
        } catch (Throwable error) {
            emitError("SYSTEMUI_PACKAGE_DIAGNOSTIC_FAILED", error);
        }
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        super.onPackageReady(param);
        try {
            // Só observa; não toca em classes do SystemUI. Usa apenas getClassLoader(),
            // confirmado no javadoc de PackageReadyParam. O filtro por pacote vem da
            // flag marcada em onPackageLoaded (a assinatura de nome de pacote em
            // PackageReadyParam não foi verificada nesta milestone).
            if (systemUiSeen) {
                emit(Log.INFO, "SYSTEMUI_PACKAGE_READY"
                        + " classLoader=" + param.getClassLoader().getClass().getName());
            }
        } catch (Throwable error) {
            emitError("SYSTEMUI_PACKAGE_READY_DIAGNOSTIC_FAILED", error);
        }
    }

    /** Escreve no log do framework (Vector) e no logcat; nunca propaga exceção. */
    private void emit(int priority, String message) {
        try {
            log(priority, TAG, message);
        } catch (Throwable ignored) {
            // Falha de log não pode afetar o processo hospedeiro.
        }
        try {
            Log.println(priority, TAG, message);
        } catch (Throwable ignored) {
            // idem
        }
    }

    private void emitError(String message, Throwable error) {
        try {
            log(Log.ERROR, TAG, message, error);
        } catch (Throwable ignored) {
            // idem
        }
    }
}
