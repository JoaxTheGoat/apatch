import struct, sys, collections

def uleb(d,p):
    r=0;s=0
    while True:
        b=d[p];p+=1
        r|=(b&0x7f)<<s
        if not b&0x80: return r,p
        s+=7

def mutf8(d,p):
    _,p=uleb(d,p); e=d.index(b'\0',p)
    return d[p:e].decode('utf-8','replace')

class Dex:
    def __init__(s,path):
        d=s.d=open(path,'rb').read()
        s.magic=d[:8]
        (s.ssz,s.soff,s.tsz,s.toff,s.psz,s.poff,s.fsz,s.foff,s.msz,s.moff,s.csz,s.coff)=struct.unpack_from('<12I',d,0x38)
        s._str={}
    def string(s,i):
        if i not in s._str:
            off=struct.unpack_from('<I',s.d,s.soff+4*i)[0]; s._str[i]=mutf8(s.d,off)
        return s._str[i]
    def strings(s):
        for i in range(s.ssz): yield s.string(i)
    def type(s,i): return s.string(struct.unpack_from('<I',s.d,s.toff+4*i)[0])
    def proto(s,i):
        sh,r,po=struct.unpack_from('<III',s.d,s.poff+12*i)
        params=[]
        if po:
            n=struct.unpack_from('<I',s.d,po)[0]
            for k in range(n): params.append(s.type(struct.unpack_from('<H',s.d,po+4+2*k)[0]))
        return s.type(r),params
    def field(s,i):
        c,t,n=struct.unpack_from('<HHI',s.d,s.foff+8*i); return s.type(c),s.type(t),s.string(n)
    def method(s,i):
        c,p,n=struct.unpack_from('<HHI',s.d,s.moff+8*i); return s.type(c),s.string(n),s.proto(p)
    def classes(s):
        for i in range(s.csz):
            ci,af,sup,ifs,sf,ann,cd,sv=struct.unpack_from('<8I',s.d,s.coff+32*i)
            yield dict(idx=i,name=s.type(ci),flags=af,super=(s.type(sup) if sup!=0xffffffff else None),
                       interfaces=s.ifaces(ifs),src=(s.string(sf) if sf!=0xffffffff else None),cdata=cd)
    def ifaces(s,off):
        if not off: return []
        n=struct.unpack_from('<I',s.d,off)[0]
        return [s.type(struct.unpack_from('<H',s.d,off+4+2*k)[0]) for k in range(n)]
    def classdata(s,c):
        off=c['cdata']
        if not off: return [],[],[],[]
        d=s.d
        sf,off=uleb(d,off);inf,off=uleb(d,off);dm,off=uleb(d,off);vm,off=uleb(d,off)
        def fields(n,off):
            out=[];prev=0
            for _ in range(n):
                diff,off=uleb(d,off);fl,off=uleb(d,off);prev+=diff;out.append((s.field(prev),fl))
            return out,off
        def methods(n,off):
            out=[];prev=0
            for _ in range(n):
                diff,off=uleb(d,off);fl,off=uleb(d,off);co,off=uleb(d,off);prev+=diff;out.append((s.method(prev),fl,co))
            return out,off
        a,off=fields(sf,off);b,off=fields(inf,off);m1,off=methods(dm,off);m2,off=methods(vm,off)
        return a,b,m1,m2
