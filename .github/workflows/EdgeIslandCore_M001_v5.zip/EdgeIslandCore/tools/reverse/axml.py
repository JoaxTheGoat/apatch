import struct, sys

RES_STRING_POOL=0x0001; RES_XML=0x0003
START_NS=0x0100; END_NS=0x0101; START_EL=0x0102; END_EL=0x0103; CDATA=0x0104; RES_MAP=0x0180

def read_pool(d, off):
    typ,hsz,size,scount,sc,flags,sstart,ststart = struct.unpack_from('<HHIIIIII', d, off)
    utf8 = bool(flags & 0x100)
    offs = struct.unpack_from('<%dI'%scount, d, off+hsz)
    base = off+sstart
    out=[]
    for o in offs:
        p = base+o
        if utf8:
            def ln(p):
                b=d[p]; p+=1
                if b&0x80: b=((b&0x7f)<<8)|d[p]; p+=1
                return b,p
            _,p = ln(p); bl,p = ln(p)
            out.append(d[p:p+bl].decode('utf-8','replace'))
        else:
            l = struct.unpack_from('<H', d, p)[0]; p+=2
            if l&0x8000:
                l=((l&0x7fff)<<16)|struct.unpack_from('<H', d, p)[0]; p+=2
            out.append(d[p:p+l*2].decode('utf-16le','replace'))
    return out, size

ANDROID_NS='http://schemas.android.com/apk/res/android'
def fmt(vt, vd, pool, strv):
    if vt==3: return pool[vd] if 0<=vd<len(pool) else strv
    if vt==18: return 'true' if vd else 'false'
    if vt==16: return str(struct.unpack('<i',struct.pack('<I',vd))[0])
    if vt==17: return '0x%x'%vd
    if vt==1: return '@0x%08x'%vd
    if vt==2: return '?0x%08x'%vd
    if vt==4: return str(struct.unpack('<f',struct.pack('<I',vd))[0])
    return '(t%d)0x%x'%(vt,vd)

def decode(path):
    d=open(path,'rb').read()
    typ,hsz,size=struct.unpack_from('<HHI',d,0)
    assert typ==RES_XML
    off=hsz; pool=[]; lines=[]; depth=0; ns={}
    while off<len(d):
        t,h,s=struct.unpack_from('<HHI',d,off)
        if t==RES_STRING_POOL: pool,_=read_pool(d,off)
        elif t==START_NS:
            line,cm,pi,ui=struct.unpack_from('<IIII',d,off+8); ns[pool[ui]]=pool[pi]
        elif t==START_EL:
            line,cm,nsi,ni,astart,asize,acount,idi,ci,si=struct.unpack_from('<IIIIHHHHHH',d,off+8)
            name=pool[ni]; attrs=[]
            ao=off+16+astart
            for i in range(acount):
                ans,an,rs,vs,vt,vd=struct.unpack_from('<IIIHxBI',d,ao+i*20) if False else struct.unpack_from('<IIIHBBI',d,ao+i*20)[:3]+(None,None,None)
                ans,an,rs,vsz,res0,vt,vd=struct.unpack_from('<IIIHBBI',d,ao+i*20)
                aname=pool[an] if an!=0xffffffff else '?'
                pre='android:' if (ans!=0xffffffff and pool[ans]==ANDROID_NS) else ''
                strv=pool[rs] if rs!=0xffffffff else ''
                attrs.append((pre+aname, strv if rs!=0xffffffff and vt!=3 else fmt(vt,vd,pool,strv)))
            lines.append((depth,name,attrs)); depth+=1
        elif t==END_EL: depth-=1
        off+=s
    return lines

if __name__=='__main__':
    for depth,name,attrs in decode(sys.argv[1]):
        a=' '.join('%s="%s"'%(k,v) for k,v in attrs)
        print('  '*depth+'<'+name+(' '+a if a else '')+'>')
