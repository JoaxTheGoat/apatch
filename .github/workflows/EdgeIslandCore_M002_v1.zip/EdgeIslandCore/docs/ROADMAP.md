# Roadmap

## M001 — Fundação
- [x] Um APK com Activity e entry point libxposed
- [x] API 102 declarada; chamadas conferidas no javadoc 102.0.0
- [x] Escopo estático restrito ao SystemUI
- [x] Diagnóstico de carregamento via log do framework
- [x] Scaffold auditado e documentação de referência do Material Capsule
- [ ] Compilar no Android Studio do usuário
- [ ] Confirmar callbacks do módulo no Vector — reconhecimento do módulo pelo manager não comprova callback no processo SystemUI

## M002 — Activity Engine (implementação inicial)
- [x] Modelo de atividade independente de Android/Xposed
- [x] Activity Registry indexado por `activityId`
- [x] Processamento serializado por Channel (actor de consumidor único)
- [x] Publicação de `IslandUiState` por StateFlow
- [x] Activity Arbiter com preservação de atividades secundárias
- [x] Regra de preempção: transitória só interrompe persistente quando `canInterrupt=true` e sua prioridade é maior
- [x] Expiração de atividades transitórias por TTL
- [x] Event Manager com preferências individuais persistidas em SharedPreferences
- [x] Tela inicial com controles de ativação/desativação por evento e categoria
- [x] Testes unitários iniciais do Arbiter
- [ ] Compilar e executar no dispositivo
- [ ] Integrar Laboratório visual e painel de diagnóstico em tempo real
- [ ] Adicionar configuração visual de prioridade, TTL e modo de apresentação
- [ ] Ligar os primeiros adapters reais (mídia e carregamento)

## M003 — Integração SystemUI
- Inventário de classes/métodos reais da build instalada (não presumir nomes).
- Primeiro hook observacional em `onPackageReady`, com id fixo, `exceptionMode` protetivo.
- Validar estabilidade (sem crash/loop do SystemUI) antes de avançar.
- Nenhum hook de modificação nesta etapa sem necessidade demonstrada.

## M004 — Adapters e Renderer
- Renderer no Core primeiro (opção B), via overlay com consentimento explícito.
- APIs públicas primeiro: MediaSession, NotificationListener, bateria/energia, Bluetooth, rede, áudio e lanterna.
- O overlay comum não tem garantia de aparecer sobre lockscreen/Quick Settings.
- Hooks seletivos só onde APIs públicas não bastarem e após inventário real.

## M005 — Recursos avançados
- Gestos, personalização, animações, sensores/eventos, consumo e desempenho.
- Acabamento: cápsula de mídia preta, capa ao lado, acentos extraídos da arte; Monet nas configurações.
