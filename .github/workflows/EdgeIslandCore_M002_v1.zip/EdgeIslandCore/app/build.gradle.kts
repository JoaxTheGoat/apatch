import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.edgeisland.core"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.edgeisland.core"
        minSdk = 32
        targetSdk = 36
        versionCode = 4
        versionName = "0.2.0-m002"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Kotlin 2.2+: o bloco kotlinOptions{} é erro de compilação; usar compilerOptions.
kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.JVM_17
    }
}

dependencies {
    // API usada apenas para compilar o entry point; fornecida pelo framework no runtime.
    // Nunca empacotar no APK (compileOnly).
    compileOnly("io.github.libxposed:api:102.0.0")

    // Coroutines: serial actor + StateFlow for the platform-independent activity engine.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    testImplementation("junit:junit:4.13.2")
}
