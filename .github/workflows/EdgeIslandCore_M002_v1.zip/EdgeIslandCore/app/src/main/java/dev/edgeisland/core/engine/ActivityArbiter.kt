package dev.edgeisland.core.engine

/**
 * Chooses a presentation without deleting activities covered by another event.
 * A transient activity only preempts a persistent one when canInterrupt is true
 * and its priority is higher. Otherwise the persistent activity remains primary.
 */
object ActivityArbiter {
    fun select(activities: Collection<IslandActivity>, now: Long): IslandUiState {
        val alive = activities.filter { activity ->
            activity.persistence == ActivityPersistence.PERSISTENT ||
                activity.expiresAtMillis == null ||
                activity.expiresAtMillis > now
        }
        val persistent = alive.filter { it.persistence == ActivityPersistence.PERSISTENT }
            .sortedWith(ordering())
        val transient = alive.filter { it.persistence == ActivityPersistence.TRANSIENT }
            .sortedWith(ordering())

        val persistentPrimary = persistent.firstOrNull()
        val interruptingTransient = transient.firstOrNull { candidate ->
            candidate.canInterrupt &&
                (persistentPrimary == null || candidate.priority > persistentPrimary.priority)
        }
        val primary = interruptingTransient ?: persistentPrimary ?: transient.firstOrNull()
        val ordered = buildList {
            primary?.let(::add)
            addAll((alive - listOfNotNull(primary)).sortedWith(ordering()))
        }
        return IslandUiState(
            primary = primary,
            secondary = ordered.drop(1),
            activities = ordered,
            generatedAtMillis = now
        )
    }

    private fun ordering() = compareByDescending<IslandActivity> { it.priority }
        .thenByDescending { it.updatedAtMillis }
        .thenBy { it.activityId }
}
