package dev.edgeisland.core

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import dev.edgeisland.core.engine.IslandEvent

class MainActivity : Activity() {
    private lateinit var eventPreferences: EventPolicyPreferences
    private lateinit var eventCount: TextView
    private lateinit var eventList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        eventPreferences = EventPolicyPreferences(this)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(0xFFF5F5F5.toInt())
        }

        content.addView(text("Edge Island", 30, true))
        content.addView(text("CORE • MILESTONE 002", 12, true).apply {
            setPadding(0, dp(4), 0, dp(22))
        })

        content.addView(section("Ambiente"))
        content.addView(info("Aplicativo", "Edge Island Core"))
        content.addView(info("Módulo", "libxposed API 102 (escopo estático)"))
        content.addView(info("Framework", "Vector — ativação manual no manager"))
        content.addView(info("Escopo", "com.android.systemui"))

        content.addView(section("Dispositivo"))
        content.addView(info("Aparelho", "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})"))
        content.addView(info("Android", "${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}"))
        content.addView(info("Build", Build.FINGERPRINT))
        content.addView(info("SystemUI", systemUiVersion()))

        content.addView(section("Gerenciador de eventos"))
        content.addView(text(
            "Escolha quais eventos podem ser apresentados pela Edge Island. " +
                "Desativar um evento não altera o funcionamento do Android.",
            14, false
        ).apply { setPadding(0, 0, 0, dp(12)) })

        eventCount = text("", 12, true).apply {
            setPadding(0, dp(10), 0, dp(8))
        }
        content.addView(eventCount)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(Button(this).apply {
            text = "Ativar todos"
            setOnClickListener {
                eventPreferences.setAllEnabled(true)
                renderEventSettings()
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply {
            text = "Desativar todos"
            setOnClickListener {
                eventPreferences.setAllEnabled(false)
                renderEventSettings()
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(actions)

        eventList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(eventList)
        renderEventSettings()

        content.addView(section("Estado da milestone"))
        content.addView(info("Activity Engine", "Motor serializado com Registry, Arbiter e StateFlow"))
        content.addView(info("Preferências", "Ativação individual salva localmente"))
        content.addView(info("Adapters Android", "Ainda não conectados nesta etapa"))
        content.addView(info("Renderer / overlay", "Ainda não implementado"))
        content.addView(info("Xposed", "Observacional; nenhum hook de modificação ativo"))

        content.addView(section("Observação"))
        content.addView(text(
            "M002 estabelece o motor e as políticas de eventos. A apresentação visual, " +
                "as fontes reais de eventos e a comunicação IPC serão integradas em etapas seguintes.",
            14, false
        ))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFFF5F5F5.toInt())
            clipToPadding = false
            addView(content)
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        }
        setContentView(scroll)
    }

    private fun renderEventSettings() {
        eventList.removeAllViews()
        val grouped = IslandEvent.entries.groupBy { it.category }
        grouped.forEach { (category, events) ->
            eventList.addView(section(category))
            events.forEach { event ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(8), dp(8), dp(8))
                    setBackgroundColor(0xFFFFFFFF.toInt())
                }
                val label = text(event.label, 14, false)
                row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val toggle = Switch(this).apply {
                    isChecked = eventPreferences.isEnabled(event)
                    setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
                        eventPreferences.setEnabled(event, checked)
                        updateEventCount()
                    }
                }
                row.addView(toggle)
                val params = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(2) }
                eventList.addView(row, params)
            }
        }
        updateEventCount()
    }

    private fun updateEventCount() {
        val enabled = IslandEvent.entries.count { eventPreferences.isEnabled(it) }
        eventCount.text = "$enabled de ${IslandEvent.entries.size} eventos ativados"
    }

    private fun systemUiVersion(): String = try {
        val info = packageManager.getPackageInfo("com.android.systemui", 0)
        "${info.versionName ?: "?"} (${info.longVersionCode})"
    } catch (e: Exception) {
        "indisponível (${e.javaClass.simpleName})"
    }

    private fun section(value: String) = text(value, 18, true).apply {
        setPadding(0, dp(24), 0, dp(10))
    }

    private fun info(label: String, value: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
            addView(text(label.uppercase(), 11, true))
            addView(text(value, 15, false))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
    }

    private fun text(value: String, size: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(0xFF171717.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.START
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
