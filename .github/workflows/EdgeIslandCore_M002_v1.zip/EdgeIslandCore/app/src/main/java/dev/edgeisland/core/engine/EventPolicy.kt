package dev.edgeisland.core.engine

/**
 * Stable event keys are persisted in SharedPreferences. Do not rename keys after release.
 */
enum class IslandEvent(
    val key: String,
    val label: String,
    val category: String,
    val defaultEnabled: Boolean = true
) {
    MEDIA("media", "Reprodução de mídia", "Mídia"),
    MEDIA_CONTROLS("media_controls", "Controles de mídia", "Mídia"),
    CHARGER_CONNECTED("charger_connected", "Conectou carregador", "Energia"),
    CHARGER_DISCONNECTED("charger_disconnected", "Desconectou carregador", "Energia"),
    BATTERY_LOW("battery_low", "Bateria fraca", "Energia"),
    BATTERY_FULL("battery_full", "Bateria carregada", "Energia"),
    BLUETOOTH("bluetooth", "Bluetooth conectado/desconectado", "Conectividade"),
    HEADPHONES("headphones", "Fone conectado/desconectado", "Conectividade"),
    WIFI("wifi", "Wi-Fi conectado/desconectado", "Conectividade"),
    MOBILE_DATA("mobile_data", "Dados móveis", "Conectividade"),
    CALLS("calls", "Chamadas", "Comunicação"),
    NOTIFICATIONS("notifications", "Notificações", "Comunicação"),
    DOWNLOADS("downloads", "Progresso de downloads", "Comunicação"),
    NAVIGATION("navigation", "Navegação", "Comunicação"),
    VOLUME("volume", "Alteração de volume", "Ferramentas"),
    BRIGHTNESS("brightness", "Alteração de brilho", "Ferramentas"),
    TORCH("torch", "Lanterna", "Ferramentas"),
    TIMER("timer", "Temporizador", "Ferramentas"),
    STOPWATCH("stopwatch", "Cronômetro", "Ferramentas");

    companion object {
        fun fromKey(key: String): IslandEvent? = entries.firstOrNull { it.key == key }
    }
}

data class EventPolicy(
    val enabled: Boolean = true,
    val priority: Int? = null,
    val ttlMillis: Long? = null,
    val canInterrupt: Boolean? = null,
    val presentationMode: PresentationMode? = null
)

/** Platform-neutral policy gate, independently testable from Android adapters. */
class EventManager(
    private val policyProvider: (IslandEvent) -> EventPolicy
) {
    fun isEnabled(event: IslandEvent): Boolean = policyProvider(event).enabled
    fun policyFor(event: IslandEvent): EventPolicy = policyProvider(event)
}
