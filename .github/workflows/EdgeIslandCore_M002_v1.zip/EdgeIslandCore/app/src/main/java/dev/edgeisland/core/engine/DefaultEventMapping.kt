package dev.edgeisland.core.engine

/** Default mapping from runtime activity types to user-facing event switches. */
object DefaultEventMapping {
    fun eventFor(kind: ActivityKind): IslandEvent? = when (kind) {
        ActivityKind.MEDIA -> IslandEvent.MEDIA
        ActivityKind.CALL -> IslandEvent.CALLS
        ActivityKind.TIMER -> IslandEvent.TIMER
        ActivityKind.STOPWATCH -> IslandEvent.STOPWATCH
        ActivityKind.NAVIGATION -> IslandEvent.NAVIGATION
        ActivityKind.NOTIFICATION -> IslandEvent.NOTIFICATIONS
        ActivityKind.CHARGING -> IslandEvent.CHARGER_CONNECTED
        ActivityKind.BLUETOOTH -> IslandEvent.BLUETOOTH
        ActivityKind.WIFI -> IslandEvent.WIFI
        ActivityKind.MOBILE_DATA -> IslandEvent.MOBILE_DATA
        ActivityKind.BATTERY_ALERT -> IslandEvent.BATTERY_LOW
        ActivityKind.VOLUME -> IslandEvent.VOLUME
        ActivityKind.BRIGHTNESS -> IslandEvent.BRIGHTNESS
        ActivityKind.TORCH -> IslandEvent.TORCH
        ActivityKind.DOWNLOAD -> IslandEvent.DOWNLOADS
        ActivityKind.CUSTOM -> null
    }
}
