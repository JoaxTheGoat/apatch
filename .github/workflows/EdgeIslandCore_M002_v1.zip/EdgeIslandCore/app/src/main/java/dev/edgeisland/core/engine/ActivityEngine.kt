package dev.edgeisland.core.engine

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.Closeable

/**
 * Single-consumer actor: all registry mutations are serialized through one Channel.
 * The engine is deliberately independent of Xposed, Android views and adapters.
 */
class ActivityEngine(
    private val eventManager: EventManager,
    private val eventForActivity: (IslandActivity) -> IslandEvent? = { activity ->
        activity.eventKey?.let(IslandEvent::fromKey) ?: DefaultEventMapping.eventFor(activity.kind)
    },
    private val clock: () -> Long = System::currentTimeMillis,
    parentScope: CoroutineScope? = null
) : Closeable {
    private val ownedJob = SupervisorJob()
    private val scope = parentScope ?: CoroutineScope(ownedJob + Dispatchers.Default)
    private val commands = Channel<ActivityCommand>(Channel.UNLIMITED)
    private val registry = linkedMapOf<String, IslandActivity>()
    private val mutableState = MutableStateFlow(IslandUiState())
    val state: StateFlow<IslandUiState> = mutableState.asStateFlow()
    private val worker: Job = scope.launch {
        for (command in commands) {
            when (command) {
                is ActivityCommand.Upsert -> {
                    val event = eventForActivity(command.activity)
                    if (event != null && !eventManager.isEnabled(event)) {
                        registry.remove(command.activity.activityId)
                    } else {
                        val policy = event?.let(eventManager::policyFor)
                        val normalized = applyPolicy(command.activity, policy)
                        registry[normalized.activityId] = normalized
                        scheduleExpiry(normalized)
                    }
                }
                is ActivityCommand.Dismiss -> registry.remove(command.activityId)
                is ActivityCommand.Expire -> {
                    val current = registry[command.activityId]
                    if (current != null &&
                        current.expiresAtMillis == command.expectedExpiry &&
                        current.persistence == ActivityPersistence.TRANSIENT &&
                        command.expectedExpiry <= clock()
                    ) registry.remove(command.activityId)
                }
                ActivityCommand.ClearTransient ->
                    registry.entries.removeAll { it.value.persistence == ActivityPersistence.TRANSIENT }
                ActivityCommand.ReconcilePolicies ->
                    registry.entries.removeAll { (_, activity) ->
                        val event = eventForActivity(activity)
                        event != null && !eventManager.isEnabled(event)
                    }
            }
            publish()
        }
    }

    fun upsert(activity: IslandActivity): Boolean {
        val event = eventForActivity(activity)
        if (event != null && !eventManager.isEnabled(event)) {
            commands.trySend(ActivityCommand.Dismiss(activity.activityId))
            return false
        }
        return commands.trySend(ActivityCommand.Upsert(activity)).isSuccess
    }

    private fun applyPolicy(activity: IslandActivity, policy: EventPolicy?): IslandActivity {
        if (policy == null) return activity
        val expiry = if (activity.persistence == ActivityPersistence.TRANSIENT && policy.ttlMillis != null) {
            clock() + policy.ttlMillis.coerceAtLeast(0L)
        } else activity.expiresAtMillis
        return activity.copy(
            priority = policy.priority ?: activity.priority,
            expiresAtMillis = expiry,
            canInterrupt = policy.canInterrupt ?: activity.canInterrupt,
            presentationMode = policy.presentationMode ?: activity.presentationMode
        )
    }

    fun dismiss(activityId: String): Boolean =
        commands.trySend(ActivityCommand.Dismiss(activityId)).isSuccess

    fun clearTransient(): Boolean =
        commands.trySend(ActivityCommand.ClearTransient).isSuccess

    /** Call after preferences change to immediately remove now-disabled activities. */
    fun refreshPolicies(): Boolean =
        commands.trySend(ActivityCommand.ReconcilePolicies).isSuccess

    private fun scheduleExpiry(activity: IslandActivity) {
        val expiry = activity.expiresAtMillis ?: return
        if (activity.persistence != ActivityPersistence.TRANSIENT) return
        scope.launch {
            val wait = (expiry - clock()).coerceAtLeast(0L)
            delay(wait)
            commands.send(ActivityCommand.Expire(activity.activityId, expiry))
        }
    }

    private fun publish() {
        val now = clock()
        registry.entries.removeAll { (_, activity) ->
            activity.persistence == ActivityPersistence.TRANSIENT &&
                activity.expiresAtMillis != null && activity.expiresAtMillis <= now
        }
        mutableState.value = ActivityArbiter.select(registry.values, now)
    }

    override fun close() {
        commands.close()
        worker.cancel()
        if (parentScopeIsOwned()) ownedJob.cancel()
    }

    // The engine only cancels the scope it created; parent scopes remain caller-owned.
    private fun parentScopeIsOwned(): Boolean = scope.coroutineContext[Job] === ownedJob
}
