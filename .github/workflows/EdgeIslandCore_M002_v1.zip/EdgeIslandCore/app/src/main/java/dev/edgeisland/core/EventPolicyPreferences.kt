package dev.edgeisland.core

import android.content.Context
import dev.edgeisland.core.engine.EventPolicy
import dev.edgeisland.core.engine.IslandEvent
import dev.edgeisland.core.engine.EventManager

/**
 * Android persistence adapter for per-event preferences.
 * Disabling an event only suppresses Edge Island presentation; it never disables
 * the underlying Android feature or revokes a system permission.
 */
class EventPolicyPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("edge_island_event_policies", Context.MODE_PRIVATE)

    fun isEnabled(event: IslandEvent): Boolean =
        prefs.getBoolean(event.key, event.defaultEnabled)

    fun setEnabled(event: IslandEvent, enabled: Boolean) {
        prefs.edit().putBoolean(event.key, enabled).apply()
    }

    fun setAllEnabled(enabled: Boolean) {
        prefs.edit().apply {
            IslandEvent.entries.forEach { putBoolean(it.key, enabled) }
        }.apply()
    }

    fun eventManager(): EventManager = EventManager { event ->
        EventPolicy(enabled = isEnabled(event))
    }
}
