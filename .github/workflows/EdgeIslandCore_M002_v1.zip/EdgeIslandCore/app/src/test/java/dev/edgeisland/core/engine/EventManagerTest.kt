package dev.edgeisland.core.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EventManagerTest {
    @Test fun disabledEventIsRejectedByPolicyGate() {
        val manager = EventManager { event ->
            EventPolicy(enabled = event != IslandEvent.CHARGER_CONNECTED)
        }
        assertFalse(manager.isEnabled(IslandEvent.CHARGER_CONNECTED))
        assertTrue(manager.isEnabled(IslandEvent.MEDIA))
    }

    @Test fun eventKeyCanDistinguishConnectedAndDisconnectedChargingEvents() {
        val connected = IslandActivity(
            activityId = "power", kind = ActivityKind.CHARGING,
            title = "Connected", eventKey = IslandEvent.CHARGER_CONNECTED.key
        )
        val disconnected = IslandActivity(
            activityId = "power", kind = ActivityKind.CHARGING,
            title = "Disconnected", eventKey = IslandEvent.CHARGER_DISCONNECTED.key
        )

        assertTrue(DefaultEventMapping.eventFor(connected.kind) == IslandEvent.CHARGER_CONNECTED)
        assertTrue(IslandEvent.fromKey(connected.eventKey!!) == IslandEvent.CHARGER_CONNECTED)
        assertTrue(IslandEvent.fromKey(disconnected.eventKey!!) == IslandEvent.CHARGER_DISCONNECTED)
    }
}
