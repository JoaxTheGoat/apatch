package dev.edgeisland.core.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActivityArbiterTest {
    @Test fun transientWithoutInterruptPermissionDoesNotReplacePersistentActivity() {
        val media = IslandActivity(
            activityId = "media", kind = ActivityKind.MEDIA, title = "Music",
            priority = 50, persistence = ActivityPersistence.PERSISTENT
        )
        val charger = IslandActivity(
            activityId = "charger", kind = ActivityKind.CHARGING, title = "Charging",
            priority = 90, persistence = ActivityPersistence.TRANSIENT,
            expiresAtMillis = 10_000, canInterrupt = false
        )

        val state = ActivityArbiter.select(listOf(media, charger), now = 1_000)
        assertEquals("media", state.primary?.activityId)
        assertEquals(2, state.activities.size)
    }

    @Test fun interruptingTransientCanTemporarilyReplacePersistentActivity() {
        val media = IslandActivity(
            activityId = "media", kind = ActivityKind.MEDIA, title = "Music",
            priority = 50, persistence = ActivityPersistence.PERSISTENT
        )
        val charger = IslandActivity(
            activityId = "charger", kind = ActivityKind.CHARGING, title = "Charging",
            priority = 90, persistence = ActivityPersistence.TRANSIENT,
            expiresAtMillis = 10_000, canInterrupt = true
        )

        val state = ActivityArbiter.select(listOf(media, charger), now = 1_000)
        assertEquals("charger", state.primary?.activityId)
        assertEquals("media", state.secondary.single().activityId)
    }

    @Test fun expiredTransientIsExcludedButPersistentRemains() {
        val media = IslandActivity(
            activityId = "media", kind = ActivityKind.MEDIA, title = "Music",
            persistence = ActivityPersistence.PERSISTENT
        )
        val charger = IslandActivity(
            activityId = "charger", kind = ActivityKind.CHARGING, title = "Charging",
            persistence = ActivityPersistence.TRANSIENT, expiresAtMillis = 500
        )

        val state = ActivityArbiter.select(listOf(media, charger), now = 1_000)
        assertEquals("media", state.primary?.activityId)
        assertTrue(state.activities.none { it.activityId == "charger" })
    }
}
